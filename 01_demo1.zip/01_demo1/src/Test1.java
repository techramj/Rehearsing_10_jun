
public class Test1 {
	
	
	public static void main(String[] args) {
		int a =10;
		int b =10;
		
		Student s1 = new Student();
		
		Employee e1 = new Employee(1, "Jack", 1000);
		Employee e2 = new Employee(1, "Jack", 1000);
		Employee e3 = new Employee(2, "Jack", 1000);
		
		System.out.println(e1 == e2); 
		
		System.out.println(a==b);
		
		System.out.println(e1.equals(e2));
		System.out.println(e1.equals(null));
		System.out.println(e1.equals(s1));
		System.out.println(e1.equals(e1));
		
		System.out.println(e1.hashCode());
		System.out.println(e2.hashCode());
		System.out.println(e3.hashCode());
		
	}

}
