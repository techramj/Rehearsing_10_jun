
public class Test {
	
	public static void main(String[] args) {
		
		Employee emp1 = new Employee();
		System.out.println(emp1);
		
		Employee emp2 = new Employee(1,"Jack", 2000);
		
		emp1 = emp2;
		
		emp1.setSalary(5000);
		
		
		//System.out.println(emp1);
		//System.out.println(emp2);
		
		/*
		 * for(long i=0;i<=999999;i++) { emp1 = new Employee(); }
		 */
		emp2 = null;
		emp1 = null;
		System.gc();

		System.out.println("end");
		
	}
	
	

}
