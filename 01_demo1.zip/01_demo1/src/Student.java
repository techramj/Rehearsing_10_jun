
public class Student {
	
	//properties / object member / object instance
	private int rollno;
	private String name;
	private  int age;
	private static String schoolName;
	

	

	//Behavior
	void display(){
		System.out.println("Roll no: "+rollno+"  name: "+name);
	}
	
	
	
	void setName(String name) {
		
		this.name = name;
	}
	
	String getName() {
		return name;
	}
	
	int getRollno() {
		return rollno;
	}
	
	void setRollno(int rollno) {
		if(rollno <= 0) {
			throw new IllegalArgumentException("Invalid Rollno. rollno cannot be less than Zero");
		}
		this.rollno = rollno;
	}

}
