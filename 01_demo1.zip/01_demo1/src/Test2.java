
public class Test2 {

	public static void main(String[] args) {
		Employee e1 = new Employee(1, "Jack", 1000);
		Employee e2 = new Employee(2, "John", 2000);
		
		swap(e1, e2);
		System.out.println(e1);
		System.out.println(e2);
		
	}
	
	public static void swap(Employee e1, Employee e2) {
		int tempId = e1.getId();
		e1.setId(e2.getId());
		e2.setId(tempId);
		
		String tempStr = e1.getName();
		e1.setName(e2.getName());
		e2.setName(tempStr);
		
		double tempSal = e1.getSalary();
		e1.setSalary(e2.getSalary());
		e2.setSalary(tempSal);
		
	}

}
