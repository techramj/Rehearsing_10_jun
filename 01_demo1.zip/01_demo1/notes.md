# Memory allocation
	## type of variables
	Instance : heap
	local  : statck
	global 
	static : data segment
	
	datatype:
	int
	float
	double
	long
	
# Pointer
		1. local variable don't have default value
		
		
# difference between
		pass by value (java)
		pass by address
		pass by reference
		
# equals method
		@Override
			public boolean equals(Object obj) {
				if (obj == null) {
					return false;
				}
				if(this == obj) {
					return true;
				}
				if (obj instanceof Employee) {
					Employee emp = (Employee) obj;
					return this.id == emp.id && this.name.equals(emp.name)
							&& Double.doubleToLongBits(this.salary) == Double.doubleToLongBits(emp.salary);
				}
				return false;
			}
		 		
		
	